from django.urls import path, include
from . import views
from . import schedule_views
from . import hybrid_views
from .connection_status import database_status
from .ptm_views import OperacionesPTMView
from .ptm_reader_views import ConciliacionPTMView, receive_ptm
from .ptm_cash_pool_views import BolsaPTMAdminView, BolsaPTMTurnoView
from .expense_views import EgresosEditarListView, EditarEgresoView
from django.contrib.auth import views as auth_views
from .views import (
                    LoginView,
                    HomePageView,
                    SucursalCreateAJAXView,
                    SucursalListView,
                    SucursalUpdateAJAXView,
                    CategoriaCreateAJAXView,
                    CategoriaListView,
                    CategoriaUpdateAJAXView,
                    ProductoCreateAJAXView,
                    CategoriaAutocompleteView,
                    ProductoListView,
                    ProductoUpdateAJAXView,
                    InventarioCreateAJAXView,
                    SucursalSinInventarioAutocomplete,
                    ProductoAutocomplete,
                    InventarioListView,
                    SucursalInventarioAutocompleteView,
                    EditarInventarioView,
                    SucursalInventarioAutocompleteEditarView,
                    ProveedorCreateView,
                    ProveedorListView,
                    ProveedorUpdateView,
                    PreciosProveedorCreateAJAXView,
                    ProveedorSinPreciosAutocomplete,
                    ProductoExcludingAutocomplete,
                    PreciosProveedorListView,
                    PreciosProveedorUpdateAJAXView,
                    ProveedorConProductosAutocomplete,
                    PuntosPagoCreateAJAXView,
                    SucursalSinPuntoPagoAutocomplete,
                    PuntosPagoListView,
                    SucursalConPuntosAutocomplete,
                    PuntosPagoUpdateAJAXView,
                    SucursalEditarPuntoPagoAutocomplete,
                    RolCreateAJAXView,
                    RolListView,
                    RolUpdateAJAXView,
                    UsuarioCreateAJAXView,
                    RolAutocompleteView,
                    UsuarioListView,
                    UsuarioUpdateAJAXView,
                    EmpleadoCreateAJAXView,
                    UsuarioDisponibleAutocomplete,
                    SucursalAutocomplete,
                    EmpleadoListView,
                    HorarioCreateAJAXView,
                    SucursalSinHorarioAutocomplete,
                    HorariosListView,
                    SucursalConHorariosAutocomplete,
                    HorarioUpdateAJAXView,
                    HorarioCajaCreateAJAXView,
                    SucursalHorarioCajaAutocomplete,

                    )



urlpatterns = [
    path("ptm/conciliacion/", ConciliacionPTMView.as_view(), name="conciliacion_ptm"),
    path("ptm/bolsas/", BolsaPTMAdminView.as_view(), name="bolsa_ptm_admin"),
    path("ptm/bolsa/turno/<int:turno_id>/", BolsaPTMTurnoView.as_view(), name="bolsa_ptm_turno"),
    path("api/ptm/lector/", receive_ptm, name="ptm_reader_receive"),
    path("api/estado-conexion/", database_status, name="database_connection_status"),
    path("api/hybrid/v1/replica/prepare/", hybrid_views.replica_prepare, name="hybrid_replica_prepare"),
    path("api/hybrid/v1/replica/page/", hybrid_views.replica_page, name="hybrid_replica_page"),
    path("configuracion/equipos-hibridos/", hybrid_views.devices, name="equipos_hibridos"),
    path("api/hybrid/v1/enroll/", hybrid_views.enroll, name="hybrid_enroll"),
    path("api/hybrid/v1/session/", hybrid_views.start_session, name="hybrid_session"),
    path("api/hybrid/v1/catalog/", hybrid_views.catalog, name="hybrid_catalog"),
    path("api/hybrid/v1/sale/", hybrid_views.sale, name="hybrid_sale"),
    path("api/hybrid/v1/expense/", hybrid_views.expense, name="hybrid_expense"),
    path("api/hybrid/v1/operation/", hybrid_views.operation, name="hybrid_operation"),
    path("api/hybrid/v1/operation-read/", hybrid_views.operation_read, name="hybrid_operation_read"),
    path("api/hybrid/v1/release/", hybrid_views.release_session, name="hybrid_release"),
    path("api/hybrid/v1/recovery/prepare/", hybrid_views.recovery_prepare, name="hybrid_recovery_prepare"),
    path("api/hybrid/v1/recovery/finish/", hybrid_views.recovery_finish, name="hybrid_recovery_finish"),
    path("", LoginView.as_view(), name="login"),

    path('home/', HomePageView.as_view(), name='home'),
    path("horarios/empleados/", schedule_views.calendar_page, name="calendario_empleados"),
    path("horarios/empleados/datos/", schedule_views.calendar_data, name="calendario_empleados_datos"),
    path("horarios/empleados/guardar/", schedule_views.calendar_save, name="guardar_turno_empleado"),
    path("horarios/empleados/rotacion/", schedule_views.rotation_create, name="crear_rotacion_empleados"),
    path("mi-horario/", schedule_views.calendar_page, {"personal": True}, name="mi_horario"),
    path("mi-horario/datos/", schedule_views.calendar_data, {"personal": True}, name="mi_horario_datos"),
    path(
        "configuracion/funcionalidades/",
        views.ConfiguracionFuncionalidadesView.as_view(),
        name="configuracion_funcionalidades",
    ),
    path(
        "configuracion/impresion/",
        views.ConfiguracionImpresionView.as_view(),
        name="configuracion_impresion",
    ),
    path(
        "configuracion/metodos-pago/",
        views.ConfiguracionMetodosPagoView.as_view(),
        name="configuracion_metodos_pago",
    ),
    path(
        "configuracion/telegram/",
        views.ConfiguracionTelegramBotView.as_view(),
        name="configuracion_telegram_bot",
    ),
    path(
        "api/telegram/webhook/",
        views.TelegramWebhookView.as_view(),
        name="telegram_webhook",
    ),

    path('agregar_sucursal/', SucursalCreateAJAXView.as_view(), name='agregar_sucursal'),
    path("visualizar_sucursales/", SucursalListView.as_view(), name="visualizar_sucursales"),
    path('sucursales/eliminar/<int:sucursal_id>/', views.eliminar_sucursal, name='eliminar_sucursal'),
    path("sucursales/editar/<int:sucursal_id>/", SucursalUpdateAJAXView.as_view(), name="editar_sucursal", ),

    path("agregar_categoria/", CategoriaCreateAJAXView.as_view(), name="agregar_categoria"),
    path("visualizar_categorias/", CategoriaListView.as_view(), name="visualizar_categorias"),
    path('categorias/eliminar/<int:categoria_id>/', views.eliminar_categoria, name='eliminar_categoria'),
    path("categorias/editar/<int:categoria_id>/", CategoriaUpdateAJAXView.as_view(), name="editar_categoria"),

    path("agregar_producto/", ProductoCreateAJAXView.as_view(), name="agregar_producto"),
    path("categoria_autocomplete/", CategoriaAutocompleteView.as_view(), name="categoria_autocomplete"),
    path('visualizar_productos/',  ProductoListView.as_view(), name='visualizar_productos'),
    path("productos/data/", views.ProductoDataTableView.as_view(), name="productos_datatable"),
    path('productos/eliminar/<int:producto_id>/', views.eliminar_producto, name='eliminar_producto'),
    path("productos/editar/<int:producto_id>/", ProductoUpdateAJAXView.as_view(), name="editar_producto"),


    path('agregar_inventario/', InventarioCreateAJAXView.as_view(), name='agregar_inventario'),
    path(
        'autocomplete/inventario/sucursal/agregar/',
        views.sucursal_inventario_agregar_autocomplete,
        name='sucursal_inventario_agregar_autocomplete',
    ),
    # Ruta para autocompletar Sucursales sin Inventario

    path("sucursal_inventario/", views.sucursal_sin_inventario_autocomplete, name="sucursal_sin_inventario_autocomplete"),
    # Ruta para autocompletar Productos (por ejemplo)
    path('autocomplete/producto_inventario/', ProductoAutocomplete.as_view(), name='producto_inventario_autocomplete'),
    path('visualizar_inventarios/', InventarioListView.as_view(), name='visualizar_inventarios'),
    path('autocomplete/sucursal_con_inventario/', SucursalInventarioAutocompleteView.as_view(), name='sucursal_con_inventario_autocomplete'),
    path('editar_inventario/<int:sucursal_id>/', EditarInventarioView.as_view(), name='editar_inventario'),
    path('autocomplete/sucursal_inventario_editar/', SucursalInventarioAutocompleteEditarView.as_view(), name='sucursal_inventario_autocomplete'),
    path("inventario/<int:sucursal_id>/item/", views.InventarioItemAjaxView.as_view(),
         name="inventario_item_ajax"),
    path("autocomplete/inventario/producto/nombre/", views.ProductoInventarioBuscarNombreView.as_view(),
         name="producto_inventario_buscar_nombre"),
    path("autocomplete/inventario/producto/barras/", views.ProductoInventarioBuscarBarrasView.as_view(),
         name="producto_inventario_buscar_barras"),
    path("autocomplete/inventario/producto/id/", views.ProductoInventarioBuscarIdView.as_view(),
         name="producto_inventario_buscar_id"),
    path('inventario/eliminar/<int:inventario_id>/', views.eliminar_producto_inventario_view, name='eliminar_producto_inventario'),

    path('agregar_proveedor/', ProveedorCreateView.as_view(), name='agregar_proveedor'),
    path("visualizar_proveedores/", ProveedorListView.as_view(), name="visualizar_proveedores"),
    path('eliminar_proveedor/<int:proveedor_id>/', views.eliminar_proveedor, name='eliminar_proveedor'),
    path("editar_proveedor/<int:proveedor_id>/", ProveedorUpdateView.as_view(), name="editar_proveedor"),


    path("agregar_productos_precios_proveedor/",PreciosProveedorCreateAJAXView.as_view(),name="agregar_productos_precios_proveedor"),
    path("autocomplete/proveedor_precios/", ProveedorSinPreciosAutocomplete.as_view(), name="proveedor_precios_autocomplete"),
    path("autocomplete/producto_precios/", ProductoExcludingAutocomplete.as_view(), name="producto_precios_autocomplete"),
    path("visualizar_precios_proveedor/", PreciosProveedorListView.as_view(), name="visualizar_productos_precios_proveedores"),
    path("autocomplete/proveedor_con_productos/", ProveedorConProductosAutocomplete.as_view(), name="proveedor_con_productos_autocomplete"),
    path('precios_proveedor/eliminar/<int:id>/', views.eliminar_precio_proveedor_view, name='eliminar_precio_proveedor'),
    path("editar_productos_precios_proveedor/<int:proveedor_id>/", PreciosProveedorUpdateAJAXView.as_view(), name="editar_productos_precios_proveedor"),

    path("agregar_punto_pago/", PuntosPagoCreateAJAXView.as_view(), name="agregar_punto_pago"),
    path("autocomplete/sucursal_punto_pago/", SucursalSinPuntoPagoAutocomplete.as_view(), name="sucursal_punto_pago_autocomplete"),
    path("visualizar_puntos_pago/", PuntosPagoListView.as_view(), name="visualizar_puntos_pago"),
    path('eliminar_punto_pago/<int:puntopagoid>/', views.eliminar_punto_pago_view, name='eliminar_punto_pago'),
    path('autocomplete/sucursal_punto_pago_visualizar/',  SucursalConPuntosAutocomplete.as_view(), name='sucursal_punto_pago_visualizar_autocomplete'),
    path("editar-puntos-pago/<int:sucursal_id>/", PuntosPagoUpdateAJAXView.as_view(), name="editar_puntos_pago"),
    path("sucursal_editar_punto_pago_autocomplete/", SucursalEditarPuntoPagoAutocomplete.as_view(), name="sucursal_editar_punto_pago_autocomplete"),

    path("agregar_rol/", RolCreateAJAXView.as_view(), name="agregar_rol"),
    path("visualizar_roles/", RolListView.as_view(), name="visualizar_roles"),
    path("roles/editar/<int:rol_id>/", RolUpdateAJAXView.as_view(), name="editar_rol"),
    path('eliminar_rol/<int:rol_id>/', views.eliminar_rol_view, name='eliminar_rol'),


    path("agregar_usuario/",      UsuarioCreateAJAXView.as_view(), name="agregar_usuario"),
    path("rol_autocomplete/",     RolAutocompleteView.as_view(),   name="rol_autocomplete_usuarios"),
    path("visualizar_usuarios/", UsuarioListView.as_view(), name="visualizar_usuarios"),
    path('eliminar_usuario/<int:usuarioid>/', views.eliminar_usuario_view, name='eliminar_usuario'),
    path("usuarios/editar/<int:usuario_id>/", UsuarioUpdateAJAXView.as_view(), name="editar_usuario"),


    path("agregar_empleado/", EmpleadoCreateAJAXView.as_view(), name="agregar_empleado"),
    path("autocomplete/usuario/",   UsuarioDisponibleAutocomplete.as_view(), name="usuario_autocomplete"),
    path(
        "autocomplete/empleados/sucursal/",
        SucursalAutocomplete.as_view(),
        name="empleado_sucursal_autocomplete",
    ),
    path("visualizar_empleados/",EmpleadoListView.as_view(), name="visualizar_empleados"),
    path("empleados/editar/<int:empleado_id>/", views.EmpleadoUpdateAJAXView.as_view(), name="editar_empleado"),
    path('eliminar_empleado/<int:empleado_id>/', views.eliminar_empleado_view, name='eliminar_empleado'),

    path("agregar_horario/", HorarioCreateAJAXView.as_view(),name="agregar_horario"),
    path("autocomplete/sucursal_horario/", SucursalSinHorarioAutocomplete.as_view(), name="horarios_sucursal_autocomplete"),
    path("visualizar_horarios/", HorariosListView.as_view(), name="visualizar_horarios"),
    path("autocomplete/sucursal_horario_visualizar/", SucursalConHorariosAutocomplete.as_view(), name="sucursal_horario_visualizar_autocomplete"),
    path("editar_horarios/<int:sucursal_id>/", HorarioUpdateAJAXView.as_view(), name="editar_horarios"),
    path('eliminar_horario/<int:horario_id>/', views.eliminar_horario_view, name='eliminar_horario'),

    path("agregar_horario_caja/",HorarioCajaCreateAJAXView.as_view(),name="agregar_horario_caja"),
    path("autocomplete/caja/sucursal/", views.SucursalAgregarHorarioCajaAutocomplete.as_view(), name="sucursal_horario_caja_autocomplete"),
    path("autocomplete/caja/puntopago/", views.PuntosPagoAgregarHorarioCajaAutocomplete.as_view(), name="puntopago_horario_caja_autocomplete"),
    path("visualizar_horarios_cajas/", views.VisualizarHorariosCajasView.as_view(), name="visualizar_horarios_cajas"),
    path("autocomplete/sucursal_horarios_cajas/", views.SucursalHorarioCajaAutocomplete.as_view(), name="visualizar_horarios_cajas_sucursal_autocomplete"),
    path("autocomplete/puntopago_horarios_cajas/", views.PuntoPagoHorarioCajaAutocomplete.as_view(), name="visualizar_horarios_cajas_puntopago_autocomplete"),
    path('eliminar_horario_caja/<int:horario_id>/', views.eliminar_horario_caja_view, name='eliminar_horario_caja'),
    path("editar_horarios_cajas/<int:puntopagoid>/", views.EditarHorarioCajaView.as_view(), name="editar_horarios_cajas"),
    path("autocomplete/sucursal_caja_editar/", views.SucursalDisponibleCajaAutocomplete.as_view(), name="sucursal_caja_editar_autocomplete"),
    path("autocomplete/puntopago_caja_editar/", views.PuntoCajaDisponibleAutocomplete.as_view(), name="puntopago_caja_editar_autocomplete"),


    path("agregar_cliente/", views.ClienteCreateAJAXView.as_view(), name="agregar_cliente"),
    path("visualizar_clientes/", views.ClienteListView.as_view(), name="visualizar_clientes"),
    path("clientes/editar/<int:cliente_id>/",views.ClienteUpdateAJAXView.as_view(),name="editar_cliente"),
    path('eliminar_cliente/<int:clienteid>/', views.eliminar_cliente, name='eliminar_cliente'),


    path("generar_venta/", views.GenerarVentaView.as_view(), name="generar_venta"),
    path(
        "ventas/merk2888/claves/",
        views.ClavesDescuentoMerk2888View.as_view(),
        name="claves_descuento_merk2888",
    ),
    path("autocomplete/producto-id/", views.ProductoIdAutocompleteView.as_view(), name="producto_autocomplete_id"),
    path("api/productos/snapshot/", views.ProductoSnapshotView.as_view(), name="producto_snapshot"),
    path("ventas/imprimir/", views.ImprimirFacturaView.as_view(), name="imprimir_factura"),
    path("ventas/abrir-caja/", views.AbrirCajaView.as_view(),      name="abrir_caja"),
    path("ventas/auditoria/carrito-limpiado/", views.VentaCarritoLimpioAuditView.as_view(), name="venta_carrito_limpio_audit"),

    # Autocompletes
    path('autocomplete/sucursal/',   views.VentaSucursalAutocompleteView.as_view(),
         name='sucursal_autocomplete'),

    path('autocomplete/puntopago/',  views.PuntoPagoAutocompleteView.as_view(),
         name='puntopago_autocomplete'),

    path('autocomplete/cliente/',    views.ClienteAutocompleteView.as_view(),
         name='cliente_autocomplete'),

    path('autocomplete/producto/',   views.ProductoAutocompleteView.as_view(),
         name='producto_autocomplete'),

    # AJAX utilitarios
    path("verificar_producto/",       views.VerificarProductoView.as_view(),       name="verificar_producto"),
    path("producto_por_codigo/",      views.BuscarProductoPorCodigoView.as_view(), name="buscar_producto_por_codigo"),
    path('autocomplete/producto-codigo/',  views.ProductoCodigoAutocompleteView.as_view(),  name='producto_autocomplete_codigo'),
    path('autocomplete/producto-barras/',  views.ProductoBarrasAutocompleteView.as_view(),  name='producto_autocomplete_barras'),
    path('autocomplete/producto-global/',  views.ProductoAutocompleteGlobalView.as_view(),  name='producto_autocomplete_global'),

    path('visualizar_ventas/', views.VentaListView.as_view(), name='visualizar_ventas'),
    path("ventas/data/", views.VentaDataTableView.as_view(), name="ventas_datatable"),
    path("ventas/no-realizadas/", views.VentaCarritoAuditListView.as_view(), name="ventas_no_realizadas"),
    #  … otras urls …
    path('ver_venta/<int:venta_id>/', views.VentaDetailView.as_view(), name='ver_venta'),
    path("ventas/ticket-texto/", views.TicketTextoView.as_view(), name="ticket_texto"),
    path("cambios/", views.CambiosListView.as_view(), name="visualizar_cambios"),
    path("agregar_pedido/", views.PedidoProveedorCreateAJAXView.as_view(), name="agregar_pedido"),
    path(
        "autocomplete/pedidos/sucursal/",
        SucursalAutocomplete.as_view(),
        name="pedido_sucursal_autocomplete",
    ),
    path("autocomplete/producto_pedido/", views.ProductoPedidoAutocomplete.as_view(), name="producto_pedido_autocomplete"),
    path("visualizar_pedidos/", views.PedidoListView.as_view(), name="visualizar_pedidos"),
    path('eliminar_pedido/<int:pedido_id>/', views.eliminar_pedido, name='eliminar_pedido'),
    path('ver_pedido/<int:pedido_id>/', views.PedidoDetailView.as_view(), name='ver_pedido'),
    path('editar_pedido/<int:pedido_id>/', views.EditarPedidoView.as_view(), name='editar_pedido'),
     path("logout/", auth_views.LogoutView.as_view(next_page="login"), name="logout"),

     path("visualizar_permisos/", views.PermisoListView.as_view(), name="visualizar_permisos"),

    path("roles_permisos/", views.RolPermisoAssignView.as_view(), name="roles_permisos"),
    path("autocomplete/rol/", views.RolAutocomplete.as_view(), name="rol_autocomplete"),
    path("autocomplete/permiso/", views.PermisoAutocomplete.as_view(), name="permiso_autocomplete"),
    path("roles_permisos/visualizar/", views.VisualizarRolesPermisosView.as_view(),
     name="visualizar_roles_permisos"),
    path("autocomplete/rol_con_permisos/", views.RolConPermisosAutocomplete.as_view(),
     name="rol_con_permisos_autocomplete"),
    path("roles_permisos/eliminar/<int:rp_id>/",
     views.eliminar_rol_permiso_view, name="eliminar_rol_permiso"),
    # Editar roles ↔ permisos
     path("roles_permisos/editar/<int:rol_id>/", views.RolesPermisosEditView.as_view(),
         name="editar_roles_permisos"),

     path("autocomplete/permiso_para_rol/", views.PermisoParaRolAutocomplete.as_view(),
         name="permiso_para_rol_autocomplete"),
     path("usuarios_permisos/", views.UsuarioPermisoAssignView.as_view(),
         name="usuarios_permisos"),

     path("ventas_diarias/", views.VentasDiariasView.as_view(), name="ventas_diarias"),
     path("autocomplete/sucursal_ventas/", views.SucursalParaVentasAutocomplete.as_view(),
     name="sucursal_ventas_autocomplete"),
     path("autocomplete/puntopago_ventas/", views.PuntoPagoParaVentasAutocomplete.as_view(),
     name="puntopago_ventas_autocomplete"),
     path("ventas/diarias/stats/", views.VentasDiariasStatsView.as_view(), name="ventas_diarias_stats"),
     path("reportes/metricas/", views.MetricasNegocioView.as_view(), name="metricas_negocio"),
     path("reportes/metricas/data/", views.MetricasNegocioDataView.as_view(), name="metricas_negocio_data"),
    path("caja/registrar-pago/", views.RegistrarEgresoView.as_view(), name="registrar_egreso"),
    path("caja/pagos/", EgresosEditarListView.as_view(), name="pagos_editar_lista"),
    path("caja/pagos/<int:egreso_id>/editar/", EditarEgresoView.as_view(), name="editar_egreso"),
     path("nequi/notificaciones/", views.NequiNotificacionesView.as_view(), name="nequi_notificaciones"),
     path("nequi/notificaciones/data/", views.NequiNotificacionesDataView.as_view(), name="nequi_notificaciones_data"),
     path("nequi/notificaciones/<int:notificacion_id>/eliminar/", views.NequiNotificacionEliminarView.as_view(), name="nequi_notificacion_eliminar"),
     path("nequi/notificaciones/eliminar-seleccionadas/", views.NequiNotificacionesEliminarSeleccionadasView.as_view(), name="nequi_notificaciones_eliminar_seleccionadas"),
     path("nequi/notificaciones/disponibles/", views.NequiNotificacionesDisponiblesView.as_view(), name="nequi_notificaciones_disponibles"),
     path("api/macrodroid/nequi/", views.NequiNotificationWebhookView.as_view(), name="macrodroid_nequi_webhook"),


     # --- Reporte: pedidos pagados ---
     path("reportes/pedidos_pagados/", views.PedidosPagadosView.as_view(),
          name="pedidos_pagados"),

     # Autocomplete (solo sucursales con pedidos recibidos/pagados)
     path("autocomplete/sucursal_con_pedidos_pagados/",
          views.SucursalConPedidosPagadosAutocomplete.as_view(),
          name="sucursal_con_pedidos_pagados_autocomplete"),

     # Autocomplete de puntos de pago, filtrado por sucursal
     path("autocomplete/puntopago_con_pedidos_pagados/",
          views.PuntosPagoConPedidosPagadosAutocomplete.as_view(),
          name="puntopago_con_pedidos_pagados_autocomplete"),




     path("ptm/", OperacionesPTMView.as_view(), name="operaciones_ptm"),
     path("turno_caja/", views.TurnoCajaPageView.as_view(), name="turno_caja"),
     path("turno_caja/cierre/<int:turno_id>/pagos/",
          views.TurnoCajaCierrePageView.as_view(close_page="payments"), name="turno_caja_cierre_pagos"),
     path("turno_caja/cierre/<int:turno_id>/efectivo/",
          views.TurnoCajaCierrePageView.as_view(close_page="cash"), name="turno_caja_cierre_efectivo"),
     path("turno_caja/cierre/<int:turno_id>/medios/",
          views.TurnoCajaCierrePageView.as_view(close_page="media"), name="turno_caja_cierre_medios"),

     path("turnos_caja/recuperar_o_iniciar/",
         views.TurnoCajaRecuperarOIniciarView.as_view(),
         name="turno_recuperar_o_iniciar"),

    path("turno_caja/autocomplete/puntopago/", views.PuntoPagoAutocomplete.as_view(),
         name="turno_caja_puntopago_ac"),
    path("turno_caja/autocomplete/cajero/", views.CajeroAutocomplete.as_view(),
         name="turno_caja_cajero_ac"),

    path("turno_caja/api/iniciar/", views.TurnoCajaIniciarApi.as_view(),
         name="turno_caja_iniciar"),
    path("turno_caja/api/iniciar_cierre/", views.TurnoCajaIniciarCierreApi.as_view(),
         name="turno_caja_iniciar_cierre"),
    path("turno_caja/api/cerrar/", views.TurnoCajaCerrarApi.as_view(),
         name="turno_caja_cerrar"),
    path("turno_caja/retiro/", views.TurnoCajaRetiroActualView.as_view(),
         name="turno_caja_retiro_actual"),
    path("turno_caja/retiro/<int:turno_id>/", views.TurnoCajaRetiroView.as_view(),
         name="turno_caja_retiro"),
     
     path("turnos_caja_dashboard/", views.TurnosCajaDashboardView.as_view(), name="turnos_caja_dashboard"),

    # APIs dashboard
    path("api/turnos_caja/list/", views.TurnosCajaDashboardListAPI.as_view(), name="api_turnos_caja_list"),
    path("api/turnos_caja/<int:turno_id>/", views.TurnoCajaDashboardDetailAPI.as_view(), name="api_turno_caja_detail"),

    path("turnos_caja_admin/", views.TurnosCajaAdminPageView.as_view(), name="turnos_caja_admin"),

    # APIs Admin
    path("api/admin/turnos_caja/<int:turno_id>/", views.TurnoCajaAdminDetailAPI.as_view(), name="api_admin_turno_detail"),
    path("api/admin/turnos_caja/<int:turno_id>/update/", views.TurnoCajaAdminUpdateAPI.as_view(), name="api_admin_turno_update"),
    path("api/admin/turnos_caja/<int:turno_id>/delete/", views.TurnoCajaAdminDeleteAPI.as_view(), name="api_admin_turno_delete"),





    path("a", views.GestionInventarioMasivaView.as_view(), name="inventario_masivo"),

    path("inventario/plaza-whatsapp/", views.InventarioPlazaWhatsappView.as_view(), name="inventario_plaza_whatsapp"),
    path("inventario/fotos/", views.InventarioFotosPageView.as_view(), name="inventario_fotos"),
    path("inventario/fotos/catalogo/", views.InventarioFotosCatalogoView.as_view(), name="inventario_fotos_catalogo"),
    path("inventario/fotos/proveedor/", views.InventarioFotosProveedorLookupView.as_view(), name="inventario_fotos_proveedor_lookup"),
    path("inventario/fotos/procesar/", views.InventarioFotosProcesarView.as_view(), name="inventario_fotos_procesar"),
    path("inventario/fotos/confirmar/", views.InventarioFotosConfirmarView.as_view(), name="inventario_fotos_confirmar"),

    path("autocomplete/sucursales/", views.SucursalAutocompleteView.as_view(), name="sucursal_autocomplete_simple"),

    path("autocomplete/productos/nombre/", views.ProductoBuscarNombreView.as_view(), name="producto_buscar_nombre_simple"),
    path("autocomplete/productos/barras/", views.ProductoBuscarBarrasView.as_view(), name="producto_buscar_barras_simple"),
    path("autocomplete/productos/id/", views.ProductoBuscarIdView.as_view(), name="producto_buscar_id_simple"),

    path("inventario/producto_detalle/", views.ProductoDetalleInventarioView.as_view(), name="producto_detalle_inventario"),



    path("v", views.VisorProductoBarcodeView.as_view(), name="visor_barcode"),
    path("visor/cajeros/", views.VisorProductosCajeroView.as_view(), name="visor_cajero"),
    path("visor/cajeros/buscar/", views.ProductoBuscarVisorCajeroView.as_view(), name="visor_cajero_buscar"),
    path("visor/barcode/buscar/", views.ProductoBuscarBarrasVisorView.as_view(), name="visor_barcode_buscar"),
    path("visor/barcode/lookup/", views.ProductoLookupPorBarrasVisorView.as_view(), name="visor_barcode_lookup"),



    path(
        "reportes/ventas-producto/",
        views.VentasProductoRangoView.as_view(),
        name="reporte_ventas_producto",
    ),

    # ✅ Endpoint stats (sin ID en la URL) -> sucursal_id via GET
    # /ventas/producto/stats/?sucursal_id=1&productoid=123&desde=2026-02-01&hasta=2026-02-16
    path(
        "ventas/producto/stats/",
        views.ProductoVentasStatsAjaxView.as_view(),
        name="producto_ventas_stats",
    ),

    # ✅ DataTables server-side (sin ID en la URL) -> sucursal_id via GET
    # /api/reportes/ventas-producto/?sucursal_id=1&fecha_ini=...&fecha_fin=...
    path(
        "api/reportes/ventas-producto/",
        views.VentasProductoRangoDataView.as_view(),
        name="ventas_producto_data",
    ),
]
